#' @keywords internal
#' @useDynLib dlr, .registration = TRUE
"_PACKAGE"
