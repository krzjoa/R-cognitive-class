# Helper functions to create computational graph

#' @name .create_graph
#' @title Create graph to track computations
#' @return external pointer (EXPTREXP)
#' @useDynLib dlr create_graph
#' @export
.create_graph <- function(){
  .Call(create_graph)
}

#' @name .add_edge
#' @title Add node to computational graph
#' @useDynLib dlr add_edge
#' @export
.add_edge <- function(graph, start, end){
  .Call(add_edge, graph, start, end)
}

#' @useDynLib dlr .print_graph
#' @export
.print_graph <- function(graph){
  .C(print_graph)
}


