#include <R.h>
#include <Rinternals.h>
#include <Rdefines.h>

// http://lagodiuk.github.io/computer_science/2016/12/19/efficient_adjacency_lists_in_c.html
// http://www.mathcs.emory.edu/~cheung/Courses/255/Syllabus/2-C-adv-data/dyn-array.html
// https://www.geeksforgeeks.org/graph-and-its-representations/

// Structures to handle computational graph

//' Atomic operation: divide into tensor and function
//' dest: object id
//' next: pointer to adjacent ops
struct Ops{
  int dest;
  struct Ops* next;
};

struct OperationStack{
  struct Ops* head;
};

struct Graph{
  int V;
  struct OperationStack* ops_stack;
};

struct Ops* new_node(int dest){
  struct Ops* p = (struct Ops*) calloc(1, sizeof(struct Ops));
  p->dest = dest;
  p->next = NULL;
  return p;
}

static void _graph_finalizer(SEXP ext)
{
  struct Graph *ptr = (struct Graph*) R_ExternalPtrAddr(ext);
  Free(ptr);
}


SEXP create_graph(SEXP nodes){
  int V = asInteger(nodes);
  struct Graph* graph = (struct Graph*) malloc(sizeof(struct Graph));
  graph->V = V;

  graph->ops_stack = (struct OperationStack*) malloc(V * sizeof(struct OperationStack));

  int i;
  for (i = 0; i < V; i++)
    graph->ops_stack[i].head = NULL;

  SEXP ptr_graph = PROTECT(R_MakeExternalPtr(graph, R_NilValue, R_NilValue));
  R_RegisterCFinalizerEx(ptr_graph, _graph_finalizer, TRUE);
  UNPROTECT(1);

  return ptr_graph;
}

SEXP add_edge(SEXP graph_ptr, SEXP src, SEXP dest){
  struct Graph *graph = (struct Graph*) R_ExternalPtrAddr(graph_ptr);
  struct Ops* node = new_node(asInteger(src));
  node->next = graph->ops_stack[asInteger(src)].head;
  graph->ops_stack[asInteger(dest)].head = node;
  return graph_ptr;
}

void print_graph(SEXP graph_ptr)
{
  struct Graph *graph = (struct Graph*) R_ExternalPtrAddr(graph_ptr);
  int v;
  for (v = 0; v < graph->V; ++v)
  {
    struct Ops* pCrawl = graph->ops_stack[v].head;
    printf("\n Adjacency list of vertex %d\n head ", v);
    while (pCrawl)
    {
      printf("-> %d", pCrawl->dest);
      pCrawl = pCrawl->next;
    }
    printf("\n");
  }
}


void test(){
  // create the graph given in above fugure
  // int V = 5;
  //struct Graph* graph = create_graph(V);
  //add_edge(graph, 0, 1);
  //add_edge(graph, 0, 4);
  //add_edge(graph, 1, 2);
  //add_edge(graph, 1, 3);
  //add_edge(graph, 1, 4);
  //add_edge(graph, 2, 3);
  //add_edge(graph, 3, 4);

  // print the adjacency list representation of the above graph
  //print_graph(graph);

  //SEXP ptr_graph = PROTECT(R_MakeExternalPtr(graph, R_NilValue, R_NilValue));
  //R_RegisterCFinalizerEx(ptr_graph, _graph_finalizer, TRUE);
  //UNPROTECT(1);

  //return ptr_graph;
}

SEXP graph_vertices(SEXP ptr){
  struct Graph *graph = (struct Graph*) R_ExternalPtrAddr(ptr);
  return ScalarInteger(graph->V);
}

